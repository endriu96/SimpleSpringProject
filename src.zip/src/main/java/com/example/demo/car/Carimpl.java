package com.example.demo.car;

import com.example.demo.engine.Engine;

public class Carimpl implements Car{
    private String name;
    private Engine engine;
    private String color;
    private int wheelsSize;

    public Carimpl(String name,Engine engine){
        this.name=name;
        this.engine=engine;

    }


    @Override
    public String getName() {
        return name;
    }

    @Override
    public Engine getEngine() {
        return engine;
    }

    @Override
    public void setColor(String color) {
         this.color=color;
    }

    @Override
    public String getColor() {
        return color;
    }

    @Override
    public void setWheelsSize(int wheelsSize) {
            this.wheelsSize=wheelsSize;
    }

    @Override
    public int getWheelsSize() {
        return wheelsSize;
    }
}
