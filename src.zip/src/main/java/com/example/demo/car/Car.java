package com.example.demo.car;

import com.example.demo.engine.Engine;

public interface Car {
    String getName();
    Engine getEngine();
    void setColor(String color);
    String getColor();
    void setWheelsSize(int wheelsSize);
    int getWheelsSize();

}
