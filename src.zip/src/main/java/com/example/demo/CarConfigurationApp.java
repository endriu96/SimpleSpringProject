package com.example.demo;

import com.example.demo.car.Car;
import com.example.demo.engine.Engine;
import com.example.demo.service.CarOfferService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public  class CarConfigurationApp implements CommandLineRunner {

    private static final Logger LOG= LoggerFactory.getLogger(CarConfigurationApp.class);


    @Autowired
    ApplicationContext applicationContext;

    @Autowired
    CarOfferService carOfferService;


    public static void main(String[]args){

        SpringApplication.run(CarConfigurationApp.class,args);
    }



    @Override
    public void run(String... args) throws Exception {

        Engine engine1=applicationContext.getBean("enginePetrol20",Engine.class);
        Engine engine2=applicationContext.getBean("enginePetrol20", Engine.class);
        Car car1=applicationContext.getBean("mazdaCx5Petrol25", Car.class);
        Car car2=applicationContext.getBean("mazdaCx5Petrol25",Car.class);
        LOG.info("engine1==engine2={}", engine1==engine2);
        LOG.info("car1==car2={}", car1==car2);

        prepareAndSendOffer("mazda6Petrol20", "Biały", 17, "kamil@gmail.com");
        prepareAndSendOffer("mazda6Petrol25", "Biały", 19, "kamila@gmail.com");
        prepareAndSendOffer("mazda6Diesel22", "Szary", 16, "weronnika@gmail.com");
        prepareAndSendOffer("mazdaCx5Petrol20", "Czerwony", 18, "ania@gmail.com");
        prepareAndSendOffer("mazdaCx5Petrol25","Czarny", 19, "rafał@gmail.com");
        prepareAndSendOffer("mazdaCx5Diesel22", "Biały", 16, "natalia@gmail.com");

    }

    private void prepareAndSendOffer(String carBeanName,String carColor,int carWheelSize, String clientEmail){
        Car car=applicationContext.getBean(carBeanName, Car.class);

        car.setColor(carColor);
        car.setWheelsSize(carWheelSize);


        carOfferService.prepareAndSendOffer(car,clientEmail);
    }
}
