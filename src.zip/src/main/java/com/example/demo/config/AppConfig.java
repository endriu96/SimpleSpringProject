package com.example.demo.config;

import com.example.demo.car.Car;
import com.example.demo.car.Carimpl;
import com.example.demo.engine.EEngineType;
import com.example.demo.engine.Engine;
import com.example.demo.engine.EngineImp;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {

    @Value("${engine.petrol.20:}")
    private String enginePetrol20Name;


    @Value("${engine.petrol.25:}")
    private String enginePetrol25Name;

    @Value("${engine.petrol.22:}")
    private String engineDiesel22Name;

    @Value("${car.mazda.6}")
    private String carMazda6Name;

    @Value("${car.mazda.cx5}")
    private String carMazdaCx5Name;

    @Bean("enginePetrol20")
    public Engine enginePetrol20() {
        return new EngineImp
                (EEngineType.PETROL, enginePetrol20Name, 165, "6MT", 1988);
    }

    @Bean("enginePetrol25")
    public Engine enginePetrol25() {
        return new EngineImp
                (EEngineType.PETROL, enginePetrol25Name, 194, "6AT", 2488);
    }

    @Bean("engineDiesel22")
    public Engine engineDiesel22() {
        return new EngineImp
                (EEngineType.DIESEL, engineDiesel22Name, 184, "6AT", 2191);
    }

    @Bean("mazda6Petrol20")
    @Scope("prototype")
    public Car mazda6Petrol20() {
        return new Carimpl(carMazda6Name, enginePetrol20());
    }


    @Bean("mazda6Petrol25")
    @Scope("prototype")
    public Car mazda6Petrol25() {
        return new Carimpl(carMazda6Name, enginePetrol25());
    }

    @Bean("mazda6Diesel22")
    @Scope("prototype")
    public Car mazda6Diesel22() {
        return new Carimpl(carMazda6Name, engineDiesel22());
    }

    @Bean("mazdaCx5Petrol20")
    @Scope("prototype")
    public Car mazdaCx5Petrol20() {
        return new Carimpl(carMazdaCx5Name, enginePetrol20());
    }

    @Bean("mazdaCx5Petrol25")
    @Scope("prototype")
    public Car mazdaCx5Petrol25() {
        return new Carimpl(carMazdaCx5Name, enginePetrol25());
    }

    @Bean("mazdaCx5Diesel22")
    @Scope("prototype")
    public Car mazdaCx5Diesel22() {
        return new Carimpl(carMazdaCx5Name, engineDiesel22());
    }
}
