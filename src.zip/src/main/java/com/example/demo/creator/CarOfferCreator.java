package com.example.demo.creator;

import com.example.demo.car.Car;

public interface CarOfferCreator {
    String createCarOffer(Car car);

}
