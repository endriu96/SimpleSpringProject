package com.example.demo.creator;

import com.example.demo.car.Car;
import com.example.demo.engine.EEngineType;
import com.example.demo.engine.Engine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



@Component
public class CarOfferCreatorImpl implements CarOfferCreator{

    private static final String EMPTY_VALUE="-";

    @Value("${offer.header:#(null)}")
    private String offerHeader;

    @Value("${offer.footer:#(null)}")
    private String offerFooter;

    @Override
    public String createCarOffer(Car car){

        StringBuilder ab=new StringBuilder();

        if(offerHeader!=null){
            ab.append("\n");
            ab.append(offerHeader);
        }

        ab.append("\nNazwa: ");
        ab.append(car.getName());

        ab.append("\nKolor: ");
        ab.append(car.getColor());

        ab.append("\nKoła: ");
        ab.append(car.getWheelsSize());

        ab.append("\nSilnik: ");
        ab.append(createEngineDescription(car.getEngine()));

        if(offerFooter!=null){
            ab.append("\n");
            ab.append(offerFooter);

        }
        return ab.toString();

    }
    private String createEngineDescription(Engine engine){
        if(engine==null){
            return EMPTY_VALUE;
        }

        StringBuilder ab=new StringBuilder();

        ab.append("\n Typ: ");
        ab.append(mapEngineType(engine.getType()));

        ab.append("\n Nazwa: ");
        ab.append(engine.getName());

        ab.append("\n Moc (KM): ");
        ab.append(engine.getHorsepower());

        ab.append("\n Skrzynia biegów: ");
        ab.append(engine.getTransmission());

        ab.append("\n Pojemność: ");
        ab.append(engine.getCC());

        return ab.toString();


    }

    private String mapEngineType(EEngineType type){

        if(type==null){
            return  EMPTY_VALUE;
        }

        switch (type){
            case DIESEL:return "Diesel";
            case PETROL:return "Benzyna";

        }
        return EMPTY_VALUE;
    }





}
