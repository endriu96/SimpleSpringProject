package com.example.demo.engine;

public interface Engine {
    EEngineType getType();
    String getName();
    int getHorsepower();
    String getTransmission();
    int getCC();


}
