package com.example.demo.engine;

public enum EEngineType {
    DIESEL,PETROL
}
