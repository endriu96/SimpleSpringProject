package com.example.demo.service;

import com.example.demo.car.Car;

public interface CarOfferService {

    void prepareAndSendOffer(Car car, String email);
}
